#include <math330.h>
#include <math.h>

double log330(double angle)
{
    return log(angle);
}
