#ifndef MATH_330_H
#define MATH_330_H

double sin330(double);
double cos330(double);
double tan330(double);
double exp330(double);
double log330(double);
double arcsin(double);
double arccos(double);
double arctan(double);
#endif
