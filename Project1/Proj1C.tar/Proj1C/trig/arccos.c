#include <math330.h>
#include <math.h>

double arccos(double angle)
{
    return acos(angle);
}
