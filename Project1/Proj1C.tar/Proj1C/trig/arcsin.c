#include <math330.h>
#include <math.h>

double arcsin(double angle)
{
    return asin(angle);
}
